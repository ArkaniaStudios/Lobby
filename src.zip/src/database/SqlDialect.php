<?php

declare(strict_types=1);

namespace arkania\database;

interface SqlDialect {
	public const MYSQL = "mysql";

}
