<?php
declare(strict_types=1);

namespace arkania;

final class Constantes {
    public static bool $onStop = false;
}