<?php
declare(strict_types=1);

namespace arkania\commands;

use Exception;

class InvalidSenderException extends Exception {}