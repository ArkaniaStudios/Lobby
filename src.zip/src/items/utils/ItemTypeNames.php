<?php
declare(strict_types=1);

namespace arkania\items\utils;

class ItemTypeNames {
    public const ITEM_MONEY = "custom:item_money";
    public const ITEM_LOBBY = "custom:item_lobby";
}