<?php
declare(strict_types=1);

namespace arkania\session;

interface CooldownTypes {

    public const FEED = 'cooldown.feed';


}