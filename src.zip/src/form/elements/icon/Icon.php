<?php

declare(strict_types=1);

namespace arkania\form\elements\icon;

use JsonSerializable;

interface Icon extends JsonSerializable {
}
