<?php

declare(strict_types=1);

namespace arkania\database\base;

use RuntimeException;

class QueueShutdownException extends RuntimeException {
}
