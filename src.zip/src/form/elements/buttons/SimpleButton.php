<?php

declare(strict_types=1);

namespace arkania\form\elements\buttons;

final class SimpleButton extends Button {
}
