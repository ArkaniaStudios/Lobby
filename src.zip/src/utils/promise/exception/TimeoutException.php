<?php
declare(strict_types=1);

namespace arkania\utils\promise\exception;

use Exception;

class TimeoutException extends Exception {}
